/**
 * This program fixes exceptions in the methods given in the activity.
 * @author Manuel Paul
 *
 */
public class U10A1 {
	public static void main(String[] args) {
		System.out.println(divide(5,0));
		System.out.println(stringLength(""));
	}
	public static int divide(int x, int y) {
		try {
			return x / y;
		}
		catch(java.lang.ArithmeticException a) {
			if (x > 0) {
				return Integer.MAX_VALUE;
			}
			else {
				return Integer.MIN_VALUE;
			}
		}    
    }
    
    public static int stringLength(String s) {
    	try {
    		return s.length();
    	}
    	catch(java.lang.NullPointerException a) {
    		return 0;
    	}
    }
}