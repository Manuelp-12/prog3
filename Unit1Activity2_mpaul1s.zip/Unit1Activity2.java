/**
 * This class/program has a comment with my name
 * @author Manuel Paul
 *
 */
public class Unit1Activity2 {
	public static void main (String[]args) {
		
	}
}
