package concerthall;

public class ConcertHall {
	private String[][] display = new String[12][25];
	
	public ConcertHall() {
		for (int i = 0; i < display.length; i++) {
			for (int j = 0; j < display[i].length; j++) {
				if ((i >= 1 && i <= 5) && (j >= 2 && j <= 22)) {
					display[i][j] = "*";
				}
				else {
					display[i][j] = ".";
				}
			}
		}
	}
	public void reserve(int row, int column) {
		if(display[row][column].equals(".") || display[row][column].equals("*")) {
			if (isPremium(row, column)) {
				display[row][column] = "p";
				System.out.println("Your seat has been reserved");
			}
			else {
				display[row][column] = "r";
				System.out.println("Your seat has been reserved");
			}
		}
		else {
			System.out.println("This seat has already been reserved");
		}
	}
	public void cancel(int row, int column) {
		if(display[row][column].equals("p") || display[row][column].equals("r")) {
			if (!isPremium(row, column)) {
				display[row][column] = ".";
				System.out.println("Your seat has been cancelled");
			}
			else {
				display[row][column] = "*";
				System.out.println("Your seat has been cancelled");
			}
		}
		else {
			System.out.println("This seat has not been reserved");
		}
	}
	public void total() {
		double total = 0.0;
		int general = 0;
		int premium = 0;
		
		for (int i = 0; i < display.length; i++) {
			for (int j = 0; j < display[i].length; j++) {
				if (display[i][j].equals("r")) {
					total+= 10;
					general+= 1;
				}
				if (display[i][j].equals("p")) {
					total+=14.5;
					premium+= 1;
				}
			}
		}
		System.out.println("There are " + premium + " premium seats reserved");
		System.out.println("There are " + general + " general seats reserved");
		System.out.println("Total revenue: $" + total);
	}
	public void printDisplay() {
		for (int i = 0; i < 5; i++) {
			System.out.print(" ");
		}
		System.out.println("Seating Chart");
		for (int i = 0; i < display.length; i++) {
			for (int j = 0; j < display[i].length; j++) {
				System.out.print(display[i][j]);
			}
			System.out.println();
		}
		System.out.println("Legend: .=empty seat, *=empty premium seat, r=reserved seat, p=reserved premium seat");
	}
	public boolean isPremium(int row, int column) {
		if ((row >= 2 && row <= 6) && (column >= 3 && column <= 23)) {
			return true;
		}
		else {
			return false;
		}
	}
}
