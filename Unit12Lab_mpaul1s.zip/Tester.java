package tester;
import concerthall.ConcertHall;
import java.util.Scanner;
public class Tester {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		ConcertHall c = new ConcertHall();
		String command = "";
		String seat = "";
		
		System.out.println("Welcome to the concert hall reservation system");
		c.printDisplay();
		
		while(true) {
			System.out.print("Enter command (reserve, cancel, total, display, quit): ");
			command = s.nextLine();
			
			if(command.equals("reserve")) {
				System.out.print("Enter the row and column of the seat you want to reserve separated"
						+ " by a space: ");
				seat = s.nextLine();
				int row = Integer.parseInt(seat.substring(0, seat.indexOf(" ")));
				int column = Integer.parseInt(seat.substring(seat.indexOf(" ") + 1));
				if (row > 12 || column > 25) {
					System.out.println("Please enter a valid row and seat number");
				}
				else {
					c.reserve(row, column);
				}
			}
			else if (command.equals("cancel")) {
				System.out.print("Enter the row and column of the seat you want to cancel separated"
						+ " by a space: ");
				seat = s.nextLine();
				int row = Integer.parseInt(seat.substring(0, seat.indexOf(" ")));
				int column = Integer.parseInt(seat.substring(seat.indexOf(" ") + 1));
				if (row > 12 || column > 25) {
					System.out.println("Please enter a valid row and seat number");
				}
				else {
					c.cancel(row, column);
				}
			}
			else if (command.equals("total")) {
				c.total();
			}
			else if (command.equals("display")){
				c.printDisplay();
			}
			else if (command.equals("quit")) {
				break;
			}
			else {
				System.out.println("Please enter a valid response");	
			}
		}
	}
}
