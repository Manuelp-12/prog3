
public class Cheetah extends Animal {
	public Cheetah(int r, int c) {
		super(r, c);
	}
	public void move() {
		if (getAge() % 2 == 0) {
			setRow(getRow() + 2 + (int)(Math.random()*6)); //moves between 2 and 7 spaces inclusive forward
			setCol(getCol() + 2 +(int)(Math.random()*6));
		}
		else {
			setRow(getRow() - 2 - (int)(Math.random()*6)); //moves between 2 and 7 spaces inclusive backward
			setCol(getCol() - 2 - (int)(Math.random()*6));
		}
	}
	public char getSymbol() {
		return '>';
	}
	public void interactWith(Animal other, World world) {
		if (other instanceof Cheetah) {
			Cheetah otherCheetah = (Cheetah)other;
			if (Math.abs(otherCheetah.getCol() - this.getCol()) <= 1 &&
				Math.abs(otherCheetah.getRow() - this.getRow()) <= 1 &&
			    otherCheetah.getAge() > 5 && 
			    this.getAge() > 5)
				world.addAnimal(new Cheetah(this.getRow()+1, this.getCol()+1)); //two mature Cheetahs one space away reproduce 
		}
	}
	public Animal evolve() {
		if (getAge() >= 20) //lives up to 20 years
			return null;
        return this; 
	}
}
