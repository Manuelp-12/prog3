
public class Hawk extends Animal {
	public Hawk(int r, int c) {
		super(r, c);
	}

	@Override
	public char getSymbol() {
		// TODO Auto-generated method stub
		return '^';
	}

	@Override
	public void move() {
		// TODO Auto-generated method stub
		if (getAge() % 2 == 0)
			setRow(getRow() + 1 + (int)(Math.random()*6));
		else
			setRow(getRow() + -1 - (int)(Math.random()*6));
	}

	@Override
	public void interactWith(Animal other, World world) {
		if (other instanceof Rabbit) {
			Rabbit otherRabbit = (Rabbit)other;
			if (Math.abs(otherRabbit.getCol() - this.getCol()) <= 1 && Math.abs(otherRabbit.getRow() - this.getRow()) <= 1) {
				world.removeAnimal(otherRabbit);
			}		
		}
		else if (other instanceof Butterfly) {
			Butterfly otherButterfly = (Butterfly)other;
			if (Math.abs(otherButterfly.getCol() - this.getCol()) <= 1 && Math.abs(otherButterfly.getRow() - this.getRow()) <= 1) {
				world.removeAnimal(otherButterfly);
			}
		}
		else if (other instanceof Caterpillar) {
			Caterpillar otherCaterpillar = (Caterpillar)other;
			if (Math.abs(otherCaterpillar.getCol() - this.getCol()) <= 1 && Math.abs(otherCaterpillar.getRow() - this.getRow()) <= 1) {
				world.removeAnimal(otherCaterpillar);
			}
		}
	}
	
	@Override
	public Animal evolve() {
		if (getAge() >= 50)
			return null;
        return this; 
    }
}
