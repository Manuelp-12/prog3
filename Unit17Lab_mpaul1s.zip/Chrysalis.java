
public class Chrysalis extends Animal {
	private int row;
	private int col;
	
	public Chrysalis(int r, int c) {
		super(r, c);
		row = r;
		col = c;
	}
	public void move() {
		
	}
	public char getSymbol() {
		return '0';
	}
	public void interactWith(Animal other, World world) {
		
	}
	public Animal evolve() {
		if (getAge() < 3) {
			return this;
		}
		else {
			Butterfly b = new Butterfly(row, col);
			return b;
		}
	}
}