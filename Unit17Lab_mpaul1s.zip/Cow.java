
public class Cow extends Animal {
	public Cow(int r, int c) {
		super(r, c);
	}
	public void move() {
		if (getAge() % 2 == 0) { //moves every other turn
			setRow(getRow() + (int)(Math.random()*3)); //moves between 0 and 2 spaces inclusive
			setCol(getCol() + (int)(Math.random()*3));
		}
	}
	public char getSymbol() {
		return '-';
	}
	public void interactWith(Animal other, World world) {
		if (other instanceof Cow) {
			Cow otherCow = (Cow)other;
			if (Math.abs(otherCow.getCol() - this.getCol()) <= 1 &&
				Math.abs(otherCow.getRow() - this.getRow()) <= 1 &&
			    otherCow.getAge() > 5 && 
			    this.getAge() > 5)
				world.addAnimal(new Cow(this.getRow()+1, this.getCol()+1)); //two mature cows one space away reproduce 
		}
	}
	public Animal evolve() {
		if (getAge() >= 25) //lives up to 25 years
			return null;
        return this; 
	}
}