
public class Butterfly extends Animal {
	public Butterfly(int r, int c) {
		super(r, c);
	}
	public void move() {
		int rand = (int)(Math.random() * 4);
		if (rand == 0) {
			setCol(getCol() - 1);
			setRow(getRow() + 1);
		}
		else if (rand == 1) {
			setCol(getCol() + 1);
			setRow(getRow() + 1);
		}
		else if (rand == 2) {
			setCol(getCol() - 1);
			setRow(getRow() - 1);
		}
		else {
			setCol(getCol() + 1);
			setRow(getRow() - 1);
		}
	}
	public char getSymbol() {
		return '%';
	}
	public void interactWith(Animal other, World world) {
		
	}
	public Animal evolve() {
		if (getAge() >= 5)
			return null;
        return this; 
	}
}
