
public class Caterpillar extends Animal {
	private int row;
	private int col;
	
	public Caterpillar(int r, int c) {
		super(r, c);
		row = r;
		col = c;
	}
	public void move() {
		if (getAge() % 3 == 0) {
			setRow(getRow() + 1);
		}
		else {
			
		}
	}
	public char getSymbol() {
		return '~';
	}
	public void interactWith(Animal other, World world) {
		
	}
	public Animal evolve() {
		if (getAge() < 4) {
			return this;
		}
		else {
			Chrysalis ch = new Chrysalis(row, col);
			return ch;
		}
	}
}
