/**
 * This program implements multiple methods for 2D arrays like the shortest and longest items overall,
 * in each row, and in each column.
 * @author Manuel Paul
 *
 */
public class U12A1 {
	public static void main(String[] args) {
		String[][] arr = { {"abc", "de", "fghi", "j", "kl"}, 
				{"mnop", "q", "rs", "t", "u"}, 
				{"v", "xyz", "01", "23467", "789"} };
		
		System.out.println("Longest: " + findLongest(arr));
		System.out.println("Shortest: " + findShortest(arr));
		System.out.println("Longest in column 1: " + findLongestInAColumn(arr, 1));
		System.out.println("Shortest in column 1: " + findShortestInAColumn(arr, 1));
		System.out.println("Longest in row 0: " + findLongestInARow(arr, 0));
		System.out.println("Shortest in row 0: " + findShortestInARow(arr, 0));
	}
	public static String findLongest(String[][] arr) {
		String longest = arr[0][0];
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				if (arr[i][j].length() > longest.length()) {
					longest = arr[i][j];
				}
			}
		}
		return longest;
	}
	public static String findShortest(String[][] arr) {
		String shortest = arr[0][0];
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				if (arr[i][j].length() < shortest.length()) {
					shortest = arr[i][j];
				}
			}
		}
		return shortest;
	}
	public static String findLongestInAColumn(String[][] arr, int column) {
		String longest = arr[0][column];
		for (int i = 0; i < arr.length; i++) {
			if (arr[i][column].length() > longest.length()) {
				longest = arr[i][column];
			}
		}
		return longest;
	}
	public static String findShortestInAColumn(String[][] arr, int column) {
		String shortest = arr[0][column];
		for (int i = 0; i < arr.length; i++) {
			if (arr[i][column].length() < shortest.length()) {
				shortest = arr[i][column];
			}
		}
		return shortest;
	}
	public static String findLongestInARow(String[][] arr, int row) {
		String longest = arr[row][0];
		for (int i = 0; i < arr[row].length; i++) {
			if (arr[row][i].length() > longest.length()) {
				longest = arr[row][i];
			}
		}
		return longest;
	}
	public static String findShortestInARow(String[][] arr, int row) {
		String shortest = arr[row][0];
		for (int i = 0; i < arr[row].length; i++) {
			if (arr[row][i].length() < shortest.length()) {
				shortest = arr[row][i];
			}
		}
		return shortest;
	}
}
