/**
 * This program adds a weak password exception in the setpassword method of the userprofile class
 * author Manuel Paul
 */

package tester;
import userprofile.UserProfile;
import weakpasswordexception.WeakPasswordException;

public class Tester {
	public static void main(String[] args) {
		UserProfile a = new UserProfile("John", "Doe", "johndoe32@gmail.com");
		
		try {
			a.setPassword("abcdefgh1@");
		}
		catch(WeakPasswordException e) {
			e.printStackTrace();
		}
		try {
			a.setPassword("abcdefgh");
		}
		catch(WeakPasswordException e) {
			e.printStackTrace();
		}
	}
}