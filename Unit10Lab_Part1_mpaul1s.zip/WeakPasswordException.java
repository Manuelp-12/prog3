/**
 * This program adds a weak password exception in the setpassword method of the userprofile class
 * author Manuel Paul
 */

package weakpasswordexception;

public class WeakPasswordException extends Exception {
	private String message;
	
	public WeakPasswordException(String message) {
		this.message = message;
	}
	public String getMessage() {
		return message;
	}
}