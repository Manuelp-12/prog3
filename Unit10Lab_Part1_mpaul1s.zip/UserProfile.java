/**
 * This program adds a weak password exception in the setpassword method of the userprofile class
 * author Manuel Paul
 */

package userprofile;
import weakpasswordexception.WeakPasswordException;

public class UserProfile {
	private String firstName = "";
	private String lastName = "";
	private String email = "";
	private String street = "";
	private String state = "";
	private String city = "";
	private int zip = 0;
	private String password = "";
	
	public UserProfile(String fn, String ln, String e, String str, String sta, String c, int z) {
		firstName = fn;
		lastName = ln;
		email = e;
		street = str;
		state = sta;
		city = c;
		zip = z;
	}
	public UserProfile(String fn, String ln, String e) {
		firstName = fn;
		lastName = ln;
		email = e;
	}
	public void setFirstName(String x) {
		firstName = x;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setLastName(String x) {
		lastName = x;
	}
	public String getLastName() {
		return lastName;
	}
	public void setEmail(String x) {
		email = x;
	}
	public String getEmail() {
		return email;
	}
	public void setStreet(String x) {
		street = x;
	}
	public String getStreet() {
		return street;
	}
	public void setState(String x) {
		state = x;
	}
	public String getState() {
		return state;
	}
	public void setCity(String x) {
		city = x;
	}
	public String getCity() {
		return city;
	}
	public void setZip(int x) {
		zip = x;
	}
	public int getZip() {
		return zip;
	}
	public void setPassword(String s) throws WeakPasswordException {
		if (s.indexOf(firstName) != -1) {
			throw new WeakPasswordException("Password cannot include first name");
		}
		else if (s.indexOf(lastName) != -1) {
			throw new WeakPasswordException("Password cannot include last name");
		}
		else if (s.length() < 8) {
			throw new WeakPasswordException("Password must be at least 8 characters long");
		}
		else if ((s.indexOf("!") == -1) && (s.indexOf("@") == -1) && 
				(s.indexOf("#") == -1) && (s.indexOf("$") == -1) && 
				(s.indexOf("%") == -1) && (s.indexOf("^") == -1) && 
				(s.indexOf("&") == -1) && (s.indexOf("*") == -1)) {
			throw new WeakPasswordException("Password must contain at least one character from the set of !@#$%^&*");
		}
		else if ((s.indexOf("0") == -1) && (s.indexOf("1") == -1) && 
				(s.indexOf("2") == -1) && (s.indexOf("3") == -1) &&
				(s.indexOf("4") == -1) && (s.indexOf("5") == -1) && 
				(s.indexOf("6") == -1) && (s.indexOf("7") == -1)
				&& (s.indexOf("8") == -1) && (s.indexOf("9") == -1)) {
			throw new WeakPasswordException("Password must contain at least one digit");
		}
		else {
			password = s;
			System.out.println(password);
		}
	}
}