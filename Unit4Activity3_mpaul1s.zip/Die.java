/**
 * 
 * @author Manuel Paul
 *
 */
public class Die {
	private int value;
	
	public static void main (String[] args) {
		Die a = new Die();
		Die b = new Die();
		for (int i = 0; i < 3; i++) {
			System.out.println("Rolling two dice: ");
			a.roll();
			b.roll();
			System.out.println(a.getValue() + ", " + b.getValue());
		}
	}
	public Die() {
		roll();
		value = getValue();
	}
	
	public void roll() {
		value = (int)((Math.random() * 6) + 1);
	}
	public int getValue() {
		return value;
	}
}
