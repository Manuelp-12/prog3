/**
 * classes can find the location of the user and their preferred destination, and calculate the fastest route
 * @author Manuel Paul
 *
 */
public interface HasGPSCapabilities {
	String getLocation(); //finds user's location
	String getDestination(); //finds user's preferred destination
	void findFastestRoute(); //calculates the fastest route
}
