/**
 * classes can change playlists, start/stop a song or video, change volume, or go to the next or previous song
 * @author Manuel Paul
 *
 */
public interface Playable {
	void changePlaylist(); //changes a song playlist or video
	void Start(); //starts a song or video if it is paused
	void Stop(); //stops a song or video if it is playing
	void volumeControl(); //changed the volume of a song or video
	void Next(); //goes to the next song or video in a playlist
	void Previous(); //goes to the previous song or video in a playlist
}
