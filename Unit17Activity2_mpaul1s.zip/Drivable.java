/**
 * classes can go forward, backward, and turn left and right
 * @author Manuel Paul
 *
 */
public interface Drivable {
	void Forward(); //changes the gear to forward if it is in reverse
	void Reverse(); //changes the gear to reverse if it is in forward
	void turnLeft(); //turns the vehicle left
	void turnRight(); //turns the vehicle right
}
