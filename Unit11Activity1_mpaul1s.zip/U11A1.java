/**
 * This program counts integer occurances in an array
 * @author Manuel Paul
 *
 */
import java.util.Scanner;
public class U11A1 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int[] num = new int[10];
		int index1 = 0;
		int index2 = 0;
		int count = 0;
		int number = 0;
		String times = "";
		boolean check = true;
		String nums = "";
		
		System.out.print("Enter 10 integers from 1 to 50 separated by a space: ");
		nums = s.nextLine();
		
		for (int i = 0; i < nums.length(); i++) {
			String letter = String.valueOf(nums.charAt(i));
			
			if (letter.equals(" ")) {
				index2 = i;
				num[count] = Integer.valueOf(nums.substring(index1, index2).trim());
				index1 = index2;
				count++;
			}	
		}
		num[count] =Integer.valueOf(nums.substring(index2 + 1).trim());
		
		for (int i = 0; i < num.length; i++) {
			if (num[i] < 1 || num[i] > 50) {
				check = false;
			}
		}
		System.out.println("Integers must be between 1 and 50");
		
		while(check == false) {
			System.out.print("Enter 10 integers from 1 to 50 separated by a space: ");
			nums = s.nextLine();
			
			for (int i = 0; i < nums.length(); i++) {
				String letter = String.valueOf(nums.charAt(i));
				
				if (letter.equals(" ")) {
					index2 = i;
					num[count] = Integer.valueOf(nums.substring(index1, index2).trim());
					index1 = index2;
					count++;
				}	
			}
			num[count] =Integer.valueOf(nums.substring(index2 + 1).trim());
			
			for (int i = 0; i < num.length; i++) {
				if (num[i] < 1 || num[i] > 50) {
					check = false;
				}
			}
			System.out.println("Integers must be between 1 and 50");
		}
		
		for (int i = 0; i < num.length; i++) {
			int count2 = 0;
			if (!(times.contains(String.valueOf(num[i])))) {
				number = num[i];
				times = times + " " + num[i];
				
				for (int j = 0; j < num.length; j++) {
					if (number == num[j]) {
						count2++;
					}
				}
				if (count2 == 1) {
					System.out.println(number + " occurs " + count2 + " time");
				}
				else {
					System.out.println(number + " occurs " + count2 + " times");
				}	
			}
		}
	}
}