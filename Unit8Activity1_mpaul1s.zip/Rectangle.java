package rectangle;
/**
 * This program draws a rectangle with a character selected by the user and computes the area and 
 * perimeter
 * @author Manuel Paul
 *
 */
public class Rectangle {
	public static int length = 0;
	public static int width = 0;
	
	public Rectangle(int l, int w) {
		length = l;
		width = w;
	}
	public void setLength(int l) {
		length = l;
	}
	public int getLength() {
		return length;
	}
	public void setWidth(int w) {
		width = w;
	}
	public int getWidth() {
		return width;
	}
	
	public static void drawSolidRectangle(char c) {
		for (int i = 0; i < width; i++) {
			for (int j = 0; j < length; j++) {
				System.out.print(c);
			}
			System.out.println();
		}
	}
	public static int rectPerimeter() {
		int perimeter = (2 * length) + (2 * width);
		return perimeter;
	}
	public static int rectArea() {
		int area = length * width;
		return area;
	}
}