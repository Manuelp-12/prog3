package testrectangle;
import rectangle.Rectangle;
import java.util.Scanner;
/**
 * This program draws a rectangle with a character selected by the user and computes the area and 
 * perimeter
 * @author Manuel Paul
 *
 */

public class testRectangle {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		String rect = "";
		
		System.out.print("Enter rectangle's width and height separated by space(max 30): ");
		rect = s.nextLine();
		
		int a = rect.indexOf(" ");
		while (a == -1) {
			System.out.print("Please put a space between the numbers: ");
			rect = s.nextLine();
			a = rect.indexOf(" ");
		}
		
		int length = Integer.parseInt(rect.substring(0, a));
		int width = Integer.parseInt(rect.substring(a + 1, rect.length()));
		
		while(length > 30 || width > 30) {
			System.out.print("Please use numbers smaller than 30: ");
			rect = s.nextLine();
			a = rect.indexOf(" ");
			while (a == -1) {
				System.out.print("Please put a space between the numbers: ");
				rect = s.nextLine();
				a = rect.indexOf(" ");
			}
			length = Integer.parseInt(rect.substring(0, a));
			width = Integer.parseInt(rect.substring(a + 1, rect.length()));
		}	
		
		Rectangle r = new Rectangle(length, width);
		
		System.out.print("What character would you like to use: ");
		char ch = s.next().charAt(0);
		
		Rectangle.drawSolidRectangle(ch);
		System.out.println("Rectangle Area: " + Rectangle.rectArea());
		System.out.println("Rectangle Perimeter: " + Rectangle.rectPerimeter());
		
		System.out.print("Would you like to draw another rectangle (1-yes, 2-no): ");
		while(true) {
			int i = s.nextInt();
			if (i == 1) {
				reset();
				break;
			}
			else if (i == 2) {
				break;
			}
			else {
				System.out.println("Please enter a valid number");
			}
		}
	}
	public static void reset() {
		Scanner s = new Scanner(System.in);
		String rect = "";
		
		System.out.print("Enter rectangle's width and height separated by space(max 30): ");
		rect = s.nextLine();
		
		int a = rect.indexOf(" ");
		while (a == -1) {
			System.out.print("Please put a space between the numbers: ");
			rect = s.nextLine();
			a = rect.indexOf(" ");
		}
		
		int length = Integer.parseInt(rect.substring(0, a));
		int width = Integer.parseInt(rect.substring(a + 1, rect.length()));
		
		while(length > 30 || width > 30) {
			System.out.print("Please use numbers smaller than 30: ");
			rect = s.nextLine();
			a = rect.indexOf(" ");
			while (a == -1) {
				System.out.print("Please put a space between the numbers: ");
				rect = s.nextLine();
				a = rect.indexOf(" ");
			}
			length = Integer.parseInt(rect.substring(0, a));
			width = Integer.parseInt(rect.substring(a + 1, rect.length()));
		}	
		
		Rectangle r = new Rectangle(length, width);
		
		System.out.print("What character would you like to use: ");
		char ch = s.next().charAt(0);
		
		Rectangle.drawSolidRectangle(ch);
		System.out.println("Rectangle Area: " + Rectangle.rectArea());
		System.out.println("Rectangle Perimeter: " + Rectangle.rectPerimeter());
		
		System.out.print("Would you like to draw another rectangle (1-yes, 2-no): ");
		while(true) {
			int i = s.nextInt();
			if (i == 1) {
				reset();
				break;
			}
			else if (i == 2) {
				break;
			}
			else {
				System.out.println("Please enter a valid number");
			}
		}
	}
}
