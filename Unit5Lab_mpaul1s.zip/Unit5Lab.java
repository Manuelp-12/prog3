/**
 * This program calculates the perimeter, area, and volumes of 2D and 3D figures
 * @author Manuel Paul
 *
 */
import java.util.Scanner;
public class Unit5Lab {
	public static void main(String[] args) {
		Scanner s = new Scanner (System.in);
		int num;
		String string;
		String string2;
		
		System.out.println("Welcome to the Geometry Calculator");
		System.out.print("Enter 2 for 2D figures and 3 for 3D: ");
		while (true) {
			num = s.nextInt();
			if (num == 2)
				break;
			else if (num == 3)
				break;
			else
				System.out.print("Please enter a valid number: ");
		}
		
		if (num == 2) {
			System.out.print("Enter P if you are looking to compute the perimeter, A for area, or B for both: ");
			while (true) {
				string = s.nextLine();
				if (string.equals("P")) {
					break;
				}
				else if (string.equals("A")) {
					break;
				}
				else if (string.equals("B")) {
					break;
				}
				else {
					System.out.print("Please enter a valid character: ");
				}
			}
		}
		else {
			System.out.print("Enter A if you are looking to compute the area, V for volume, or B for both: ");
			while (true) {
				string = s.nextLine();
				if (string.equals("A")) {
					break;
				}
				else if (string.equals("V")) {
					break;
				}
				else if (string.equals("B")) {
					break;
				}
				else {
					System.out.print("Please enter a valid character: ");
				}
			}
		}
		
		if (num == 2) {
			System.out.print("Enter C for Circle, S for Square, and P for Parallelogram: ");
			while (true) {
				string2 = s.nextLine();
				if (string2.equals("C")) {
					break;
				}
				else if (string2.equals("S")) {
					break;
				}
				else if (string2.equals("P")) {
					break;
				}
				else {
					System.out.print("Please enter a valid character: ");
				}
			}
		}
		else {
			System.out.print("Enter S for Sphere, R for Rectangular Solid, and C for Cylinder: ");
			while (true) {
				string2 = s.nextLine();
				if (string2.equals("S")) {
					break;
				}
				else if (string2.equals("R")) {
					break;
				}
				else if (string2.equals("C")) {
					break;
				}
				else {
					System.out.print("Please enter a valid character: ");
				}
			}
		}
	
		if (num == 2 && string2.equals("C") && string.equals("P")) {
			System.out.print("Enter the radius of the circle: ");
			double side = s.nextDouble();
			System.out.println("Perimeter: " + circlePerimeter(side));
		}
		else if (num == 2 && string2.equals("C") && string.equals("A")) {
			System.out.print("Enter the radius of the circle: ");
			double side = s.nextDouble();
			System.out.println("Area: " + circleArea(side));
		}
		else if (num == 2 && string2.equals("C") && string.equals("B")) {
			System.out.print("Enter the radius of the circle: ");
			double side = s.nextDouble();
			System.out.println("Perimeter: " + circlePerimeter(side));
			System.out.println("Area: " + circleArea(side));
		}
		else if (num == 2 && string2.equals("S") && string.equals("P")) {
			System.out.print("Enter the length of the side: ");
			double side = s.nextDouble();
			System.out.println("Perimeter: " + squarePerimeter(side));
		}
		else if (num == 2 && string2.equals("S") && string.equals("A")) {
			System.out.print("Enter the length of the side: ");
			double side = s.nextDouble();
			System.out.println("Area: " + squareArea(side));
		}
		else if (num == 2 && string2.equals("S") && string.equals("B")) {
			System.out.print("Enter the length of the side: ");
			double side = s.nextDouble();
			System.out.println("Perimeter: " + squarePerimeter(side));
			System.out.println("Area: " + squareArea(side));
		}
		else if (num == 2 && string2.equals("P") && string.equals("P")) {
			System.out.print("Enter the length of the side and base: ");
			double side = s.nextDouble();
			double side2 = s.nextDouble();
			System.out.println("Perimeter: " + parallelPerimeter(side, side2));
		}
		else if (num == 2 && string2.equals("P") && string.equals("A")) {
			System.out.print("Enter the length of the side and height: ");
			double side = s.nextDouble();
			double side2 = s.nextDouble();
			System.out.println("Area: " + parallelArea(side, side2));
		}
		else if (num == 2 && string2.equals("P") && string.equals("B")) {
			System.out.print("Enter the length of the side, base, and height: ");
			double side = s.nextDouble();
			double side2 = s.nextDouble();
			double side3 = s.nextDouble();
			System.out.println("Perimeter: " + parallelPerimeter(side, side2));
			System.out.println("Area: " + parallelArea(side, side3));
		}
		else if (num == 3 && string2.equals("S") && string.equals("A")) {
			System.out.print("Enter the radius of the circle: ");
			double side = s.nextDouble();
			System.out.println("Area: " + sphereArea(side));
		}
		else if (num == 3 && string2.equals("S") && string.equals("V")) {
			System.out.print("Enter the radius of the circle: ");
			double side = s.nextDouble();
			System.out.println("Volume: " + sphereVolume(side));
		}
		else if (num == 3 && string2.equals("S") && string.equals("B")) {
			System.out.print("Enter the radius of the circle: ");
			double side = s.nextDouble();
			System.out.println("Area: " + sphereArea(side));
			System.out.println("Volume: " + sphereVolume(side));
		}
		else if (num == 3 && string2.equals("R") && string.equals("A")) {
			System.out.print("Enter the length of the side, base, and height: ");
			double side = s.nextDouble();
			double side2 = s.nextDouble();;
			double side3 = s.nextDouble();
			System.out.println("Area: " + rectArea(side, side2, side3));
		}
		else if (num == 3 && string2.equals("R") && string.equals("V")) {
			System.out.print("Enter the length of the side, base, and height: ");
			double side = s.nextDouble();
			double side2 = s.nextDouble();
			double side3 = s.nextDouble();
			System.out.println("Volume: " + rectVolume(side, side2, side3));
		}
		else if (num == 3 && string2.equals("R") && string.equals("B")) {
			System.out.print("Enter the length of the side, base, and height: ");
			double side = s.nextDouble();
			double side2 = s.nextDouble();
			double side3 = s.nextDouble();
			System.out.println("Area: " + rectArea(side, side2, side3));
			System.out.println("Volume: " + rectVolume(side, side2, side3));
		}
		else if (num == 3 && string2.equals("C") && string.equals("A")) {
			System.out.print("Enter the radius of the circle and height: ");
			double side = s.nextDouble();
			double side2 = s.nextDouble();
			System.out.println("Area: " + cylindArea(side, side2));
		}
		else if (num == 3 && string2.equals("C") && string.equals("V")) {
			System.out.print("Enter the radius of the circle and height: ");
			double side = s.nextDouble();
			double side2 = s.nextDouble();
			System.out.println("Volume: " + cylindVolume(side, side2));
		}
		else if (num == 3 && string2.equals("C") && string.equals("B")) {
			System.out.print("Enter the radius of the circle and height: ");
			double side = s.nextDouble();
			double side2 = s.nextDouble();
			System.out.println("Area: " + cylindArea(side, side2));
			System.out.println("Volume: " + cylindVolume(side, side2));
		}
		else {
			System.out.println("Error");
		}
	}
	public static double circlePerimeter(double a) {
		double perimeter = 2 * Math.PI * a;
		return perimeter;
	}
	public static double circleArea(double a) {
		double area = Math.PI * Math.pow(a, 2);
		return area;
	}
	public static double squarePerimeter(double a) {
		double perimeter = 4 * a;
		return perimeter;
	}
	public static double squareArea(double a) {
		double area = Math.pow(a, 2);
		return area;
	}
	public static double parallelPerimeter(double a, double b) {
		double perimeter = 2 * (a + b);
		return perimeter;
	}
	public static double parallelArea(double a, double b) {
		double area = a * b;
		return area;
	}
	public static double sphereArea(double a) {
		double area = 4 * Math.PI * Math.pow(a, 2);
		return area;
	}
	public static double sphereVolume(double a) {
		double volume = (4/3) * Math.PI * Math.pow(a, 3);
		return volume;
	}
	public static double rectArea(double a, double b, double c) {
		double area = 2 * ((a * b) + (a * c) + (b * c));
		return area;
	}
	public static double rectVolume(double a, double b, double c) {
		double volume = a * b * c;
		return volume;
	}
	public static double cylindArea (double a, double b) {
		double area = (2 * Math.PI * a) * (a + b);
		return area;
	}
	public static double cylindVolume (double a, double b) {
		double volume = Math.PI * Math.pow(a, 2) * b;
		return volume;
	}
}
