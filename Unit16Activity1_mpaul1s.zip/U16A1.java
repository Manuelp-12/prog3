
public class U16A1 {
	public static void main(String[] args) {
		int[] random = new int[100];
		int[] reverse = new int[100];
		int[] sorted = new int[100];
		
		for (int i = 0; i < random.length; i++) {
			random[i] = (int)((Math.random() * 100) + 1);
		}
		
		
		for (int i = 0; i < reverse.length; i++) {
			reverse[reverse.length - 1 - i] = i + 1;
		}
		
		
		for (int i = 0; i < sorted.length; i++) {
			sorted[i] = i + 1;
		}
		
		System.out.println("Merge sort on random data: ");
		long startTime = System.nanoTime ();
		mergeSort(random);
		long elapsedTime = System.nanoTime () - startTime;    
		System.out.printf ("Completed in: %d nanoseconds\n", elapsedTime);
		System.out.println();
		
		System.out.println("Merge sort on decreasing data: ");
		long startTime2 = System.nanoTime ();
		mergeSort(reverse);
		long elapsedTime2 = System.nanoTime () - startTime2;    
		System.out.printf ("Completed in: %d nanoseconds\n", elapsedTime2);
		System.out.println();
		
		System.out.println("Merge sort on increasing data: ");
		long startTime3 = System.nanoTime ();
		mergeSort(reverse);
		long elapsedTime3 = System.nanoTime () - startTime3;    
		System.out.printf ("Completed in: %d nanoseconds\n", elapsedTime3);
	}
	public static void mergeSort(int[] list) {
		if (list.length > 1) {
			int[] firstHalf = new int[list.length / 2];
			System.arraycopy(list,  0,  firstHalf,  0,  list.length / 2);
			mergeSort(firstHalf);
		
			int secondHalfLength = list.length - list.length / 2;
			int[] secondHalf = new int[secondHalfLength];
			System.arraycopy(list,  list.length / 2,  secondHalf,  0,  secondHalfLength);;
			mergeSort(secondHalf);
			
			merge(firstHalf, secondHalf, list);
		}
	}
	public static void merge(int[] list1, int[] list2, int[] temp) {
		int current1 = 0;
		int current2 = 0;
		int current3 = 0;
		while (current1 < list1.length && current2 < list2.length){
			if (list1[current1] < list2[current2]) {
				temp[current3++] = list1[current1++];
			}
			else {
				temp[current3++] = list2[current2++];
			}
		}
		
		while (current1 < list1.length) {
			temp[current3++] = list1[current1++];
		}
		while (current2 < list2.length) {
			temp[current3++] = list2[current2++];
		}
	}
}
