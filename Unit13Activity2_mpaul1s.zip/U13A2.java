/**
 * This program uses methods to compare items in ArrayLists, finding how many occurances of an object
 * there are and what items are not equal to that object.
 * @author Manuel Paul
 *
 */
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
public class U13A2 {
	public static void main(String[] args) {
		ArrayList<String> a = new ArrayList<String>();
		a.add("AA");
		a.add("B");
		a.add("C");
		a.add("B");
		LinkedList<Integer> b = new LinkedList<Integer>();
		b.add(1);
		b.add(2);
		b.add(3);
		ArrayList<Double> c = new ArrayList<Double>();
		c.add(1.5);
		c.add(1.0);
		c.add(1.5);
		
		System.out.println("ArrayList of String: " + a);
		System.out.println("count of B: " + count(a,"B"));
		System.out.print("Not matching B: ");
		printNotMatching(a, "B");
		
		System.out.println("LinkedList of Integer: " + b);
		System.out.println("count of 1: " + count(b,1));
		System.out.print("Not matching 1: ");
		printNotMatching(b, 1);
		
		System.out.println("ArrayList of Double: " + c);
		System.out.println("count of 1.5: " + count(c, 1.5));
		System.out.print("Not matching 1.5: ");
		printNotMatching(c, 1.5);
		count(c, 1.5);
		
	}
	public static <T> int count(List<T> list, Object thing) {
		
		int count = 0;
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).equals(thing)) {
				count++;
			}
		}
		return count;
	}
	public static <T> void printNotMatching(List<T> list, Object thing) {
		ArrayList<T> x = new ArrayList();
		for (int i = 0; i < list.size(); i++) {
			if (!list.get(i).equals(thing)) {
				x.add(list.get(i));
			}
		}
		System.out.println(x);
	}
}