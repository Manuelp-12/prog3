package shoppingcart;
import seat.Seat;
import java.util.ArrayList;

public class ShoppingCart {
	private ArrayList<Seat> shoppingcart = new ArrayList<Seat>();
	
	public void add(int row, int seat) {
		boolean repeat = false;
		Seat s = new Seat(row, seat);
		for (int i = 0; i < shoppingcart.size(); i++) {
			if (shoppingcart.get(i).getRow() == s.getRow() && shoppingcart.get(i).getSeat() == s.getSeat()) {
				System.out.println("Seat is already in cart");
				repeat = true;
			}
		}
		if (repeat == false) {
			shoppingcart.add(s);
		}	
	}
	public void remove(int row, int seat) {
		boolean repeat = false;
		Seat s = new Seat(row, seat);
		for (int i = 0; i < shoppingcart.size(); i++) {
			if (shoppingcart.get(i).getRow() == s.getRow() && shoppingcart.get(i).getSeat() == s.getSeat()) {
				shoppingcart.remove(i);
				repeat = true;
			}
		}
		if (repeat == false) {
			System.out.println("Seat is not in cart");
		}
	}
	public void clear() {
		shoppingcart.clear();
	}
	public void display() {
		double total = 0.0;
		for (int i = 0; i < shoppingcart.size(); i++) {
			System.out.println("Row " + shoppingcart.get(i).getRow() + " Seat " + shoppingcart.get(i).getSeat() + " $" + shoppingcart.get(i).getPrice());
			total += shoppingcart.get(i).getPrice();
		}
		System.out.println("Total: $" + total);
	}
}
