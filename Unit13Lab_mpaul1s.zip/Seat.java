package seat;

public class Seat {
	private int row;
	private int seat;
	private double price;
	
	public Seat(int r, int s) {
		row = r;
		seat = s;
		findPrice();
	}
	public int getRow() {
		return row;
	}
	public void setRow(int r) {
		row = r;
	}
	public int getSeat() {
		return seat;
	}
	public void setseat(int s) {
		seat = s;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(int p) {
		price = p;
	}
	public void findPrice() {
		if ((row >= 2 && row <= 6) && (seat >= 3 && seat <= 23)) {
			price = 14.5;
		}
		else {
			price = 10;
		}
	}
}