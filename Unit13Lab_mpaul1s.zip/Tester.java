package tester;
import seat.Seat;
import shoppingcart.ShoppingCart;
import java.util.ArrayList;
import java.util.Scanner;

public class Tester {
	public static void main(String[] args) {
		Scanner s = new Scanner (System.in);
		String command = "";
		String seat = "";
		ShoppingCart cart = new ShoppingCart();
		
		System.out.println("Welcome to the concert hall ticketing system");
		System.out.println("Here is a map of the venue: ");
		
		for (int i = 0; i < 12; i++) {
			for (int j = 0; j < 25; j++) {
				if ((i >= 1 && i <= 5) && (j >= 2 && j <= 22)) {
					System.out.print("*");
				}
				else {
					System.out.print(".");
				}
			}
			System.out.println();
		}
		System.out.println("Legend: .=empty seat, *=empty premium seat, r=reserved seat, "
				+ "p=reserved premium seat");
		
		while(true) {
			System.out.print("Enter Shopping cart operation(reserve, cancel, clear, show, purchase, "
					+ "quit): ");
			command = s.nextLine();
			
			if (command.equals("reserve")) {
				System.out.print("Enter the row and seat number separated by a space: ");
				seat = s.nextLine();
				int row = Integer.parseInt(seat.substring(0, seat.indexOf(" ")));
				int column = Integer.parseInt(seat.substring(seat.indexOf(" ") + 1));
				if (row > 12 || column > 25) {
					System.out.println("Please enter a valid row and seat number");
				}
				else {
					cart.add(row, column);
				}
			}
			else if (command.equals("cancel")) {
				System.out.print("Enter the row and seat number separated by a space: ");
				seat = s.nextLine();
				int row = Integer.parseInt(seat.substring(0, seat.indexOf(" ")));
				int column = Integer.parseInt(seat.substring(seat.indexOf(" ") + 1));
				if (row > 12 || column > 25) {
					System.out.println("Please enter a valid row and seat number");
				}
				else {
					cart.remove(row, column);
				}
			}
			else if (command.equals("clear")) {
				cart.clear();
				System.out.println("Your cart has been cleared");
			}
			else if (command.equals("show")) {
				cart.display();
			}
			else if (command.equals("purchase")) {
				System.out.println("Congratulations, you are buying the following tickets:");
				cart.display();
				break;
			}
			else if (command.equals("quit")) {
				break;
			}
			else {
				System.out.println("Please enter a valid response");
			}
		}
	}
}
