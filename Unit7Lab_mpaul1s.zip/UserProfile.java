/**
 * This program builds on the previous User Profile lab and adds additional attributes and checks if a
 * password is valid
 * @author Manuel Paul
 *
 */
import java.util.Scanner;
public class UserProfile {
	private String firstName = "";
	private String lastName = "";
	private String email = "";
	private String street = "";
	private String state = "";
	private String city = "";
	private int zip = 0;
	
	public static void main(String[] args) {
		String fn = "";
		String ln = "";
		String e = "";
		String password = "";
		
		Scanner s = new Scanner (System.in);
		
		System.out.print("First name: ");
		fn = s.nextLine();
		System.out.print("Last name: ");
		ln = s.nextLine();
		System.out.print("Email: ");
		e = s.nextLine();
		
		UserProfile a = new UserProfile(fn, ln, e);
		System.out.println("User created!");
		
		System.out.print("Please enter a new password: ");
		password = s.nextLine();
		
		while(true) {
			if (a.checkPassword(password) == true) {
				break;
			}
			else {
				System.out.print("Your password does not meet security criteria, please try again: ");
				password = s.nextLine();
			}
		}
		
		System.out.println("Your password has been changed.");
	}
	public UserProfile(String fn, String ln, String e, String str, String sta, String c, int z) {
		firstName = fn;
		lastName = ln;
		email = e;
		street = str;
		state = sta;
		city = c;
		zip = z;
	}
	public UserProfile(String fn, String ln, String e) {
		firstName = fn;
		lastName = ln;
		email = e;
	}
	public void setFirstName(String x) {
		firstName = x;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setLastName(String x) {
		lastName = x;
	}
	public String getLastName() {
		return lastName;
	}
	public void setEmail(String x) {
		email = x;
	}
	public String getEmail() {
		return email;
	}
	public void setStreet(String x) {
		street = x;
	}
	public String getStreet() {
		return street;
	}
	public void setState(String x) {
		state = x;
	}
	public String getState() {
		return state;
	}
	public void setCity(String x) {
		city = x;
	}
	public String getCity() {
		return city;
	}
	public void setZip(int x) {
		zip = x;
	}
	public int getZip() {
		return zip;
	}
	public Boolean checkPassword(String password) {
		if (password.indexOf(firstName) != -1) {
			return false;
		}
		else if (password.indexOf(lastName) != -1) {
			return false;
		}
		else if (password.length() < 8) {
			return false;
		}
		else if ((password.indexOf("!") == -1) && (password.indexOf("@") == -1) && 
				(password.indexOf("#") == -1) && (password.indexOf("$") == -1) && 
				(password.indexOf("%") == -1) && (password.indexOf("^") == -1) && 
				(password.indexOf("&") == -1) && (password.indexOf("*") == -1)) {
			return false;
		}
		else if ((password.indexOf("0") == -1) && (password.indexOf("1") == -1) && 
				(password.indexOf("2") == -1) && (password.indexOf("3") == -1) &&
				(password.indexOf("4") == -1) && (password.indexOf("5") == -1) && 
				(password.indexOf("6") == -1) && (password.indexOf("7") == -1)
				&& (password.indexOf("8") == -1) && (password.indexOf("9") == -1)) {
			return false;
		}
		else {
			return true;
		}
	}
}
