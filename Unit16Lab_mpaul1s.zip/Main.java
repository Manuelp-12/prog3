package main;
import asciimap.AsciiMap;
import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		
		System.out.println("Welcome to the paint the map program");
		AsciiMap a = new AsciiMap();
		for (;;) {
			System.out.println(a.toString());
			System.out.print("Enter row and column coordinates and character used to fill separated by space: ");
			String input = s.nextLine();
			if (input.equals("quit")) {
				break;
				/**
				 * stops loop if user types "quit"
				 */
			}
			Integer row = Integer.parseInt(input.substring(0, input.indexOf(" ")));
			input = input.substring(input.indexOf(" "));
			input = input.strip();
			Integer column = Integer.parseInt(input.substring(0, input.indexOf(" ")));
			input = input.substring(input.indexOf(" "));
			input = input.strip();
			char ch = input.charAt(0);
			a.floodFill(row, column, ch);
		}
	}
}
