/**
 * This program draws basic geometric figures using ACII characters.
 * @author Manuel Paul
 * 
 */
import java.util.Scanner;
public class Unit6Lab {
	public static void main(String[] args) {
		
		Scanner s = new Scanner (System.in);
		int rectheight;
		
		System.out.println("This program will draw a geometric figure of your choice.");
		System.out.println("Make your choice from the following:\r\n"
				+ "1 - square\r\n"
				+ "2 - rectangle\r\n"
				+ "3 - triangle\r\n"
				+ "0 - quit");
		
		while (true) {
			int num = s.nextInt();
			
			if (num == 0) {
				System.out.println("Thank you for using the program!");
				break;
			}
			else if (num == 1 || num == 2 || num == 3) {
				if (num == 1) {
					System.out.print("Please enter the side length of your square (between 1 and 30): ");
					while (true) {
						int squareside = s.nextInt();
						
						if (squareside > 0 && squareside <= 30) {
							System.out.print("Border-only or solid (enter border/solid): ");
							while (true) {
								String dummy = s.nextLine();
								String bordsol = s.nextLine();
								if (bordsol.equals("border")) {
									System.out.print("What character would you like to use: ");
									char ch = s.next().charAt(0);
									drawBorderSquare(ch, squareside);
									break;
								}
								else if (bordsol.equals("solid")) {
									System.out.print("What character would you like to use: ");
									char ch = s.next().charAt(0);
									drawSolidSquare(ch, squareside);
									break;
								}
								else {
									System.out.print("Please enter a valid response: ");
								}
							}
							break;
						}
						else {
							System.out.print("Please enter a valid number: ");
						}
					}
				}
				else if (num == 2) {
					System.out.print("Please enter the height of your rectangle (between 1 and 30): ");
					while (true) {
						rectheight = s.nextInt();
						if (rectheight > 0 && rectheight <= 30) {
							break;
						}
						else {
							System.out.print("Please enter a valid number: ");
						}
					}
					while (true) {
						System.out.print("Please enter the width of your rectangle (between 1 and 30): ");
						int rectwidth = s.nextInt();
						if (rectwidth > 0 && rectwidth <= 30) {
							System.out.print("Border-only or solid (enter border/solid): ");
							while (true) {
								String dummy = s.nextLine();
								String bordsol = s.nextLine();
								if (bordsol.equals("border")) {
									System.out.print("What character would you like to use: ");
									char ch = s.next().charAt(0);
									drawBorderRectangle(ch, rectheight, rectwidth);
									break;
								}
								else if (bordsol.equals("solid")) {
									System.out.print("What character would you like to use: ");
									char ch = s.next().charAt(0);
									drawSolidRectangle(ch, rectheight, rectwidth);
									break;
								}
								else {
									System.out.print("Please enter a valid response: ");
								}
							}
							break;
						}
						else {
							System.out.print("Please enter a valid number: ");
						}
					}
				}
				else if (num == 3) {
					System.out.print("Please enter the height of your triangle (between 1 and 30): ");
					while (true) {
						int triheight = s.nextInt();
						
						if (triheight > 0 && triheight <= 30) {
							System.out.print("Point up or down: ");
							while (true) {
								String dummy = s.nextLine();
								String updown = s.nextLine();
								
								if (updown.equals("up")) {
									System.out.print("Border-only or solid (enter border/solid): ");
									while (true) {
										String bordsol = s.nextLine();
										if (bordsol.equals("border")) {
											System.out.print("What character would you like to use: ");
											char ch = s.next().charAt(0);
											drawBorderTriangle(ch, triheight);
											break;
										}
										else if (bordsol.equals("solid")) {
											System.out.print("What character would you like to use: ");
											char ch = s.next().charAt(0);
											drawSolidTriangle(ch, triheight);
											break;
										}
										else {
											System.out.print("Please enter a valid response: ");
										}
									}
									break;
								}
								else if (updown.equals("down")){
									System.out.print("Border-only or solid (enter border/solid): ");
									while (true) {
										String bordsol = s.nextLine();
										if (bordsol.equals("border")) {
											System.out.print("What character would you like to use: ");
											char ch = s.next().charAt(0);
											drawBorderUpsideTriangle(ch, triheight);
											break;
										}
										else if (bordsol.equals("solid")) {
											System.out.print("What character would you like to use: ");
											char ch = s.next().charAt(0);
											drawSolidUpsideTriangle(ch, triheight);
											break;
										}
										else {
											System.out.print("Please enter a valid response: ");
										}
									}
									break;
								}
								else {
									System.out.print("Please enter a valid response: ");
								}
							}
							break;
						}
						else {
							System.out.print("Please enter a valid number: ");
						}
					}
				}
				break;
			}
			else {
				System.out.print("Please enter a valid number: ");
			}
		}
	}
	public static void drawSolidTriangle(char c, int height) {
		int count = 1;
		while (height >= 0) {
			for (int i = 0; i < height; i++) {
				System.out.print(" ");
			}
			for (int j = 0; j < count; j++) {
				System.out.print(c);
			}
			System.out.println();
			height--;
			count+=2;
		}
	}
	public static void drawSolidSquare(char c, int side) {
		for (int i = 0; i < side; i++) {
			for (int j = 0; j < side; j++) {
				System.out.print(c);
			}
			System.out.println();
		}
	}
	public static void drawSolidRectangle(char c, int height, int width) {
		for (int i = 0; i < height; i++) {
			for (int j = 0; j < width; j++) {
				System.out.print(c);
			}
			System.out.println();
		}
	}
	public static void drawBorderTriangle(char c, int height) {
		int count = 1;
		while (height >= 1) {
			for (int i = 0; i < height; i++) {
				System.out.print(" ");
			}
			if (!(count == 1))
					System.out.print(c);
			for (int j = 0; j < count; j++) {
				if (height == 1) {
					System.out.print(c);
				}
				else {
					System.out.print(" ");
				}
			}
			System.out.print(c);
			System.out.println();
			height--;
			count+=2;
		}
	}
	public static void drawBorderSquare(char c, int side) {
		
		for (int i = 0; i < side; i++) {
			System.out.print(c);
		}
		for (int i = 0; i < side - 2; i++) {
			System.out.println();
			System.out.print(c);
			for (int j = 0; j < side - 2; j++) {
				System.out.print(" ");
			}
			System.out.print(c);
		}
		System.out.println();
		for (int i = 0; i < side; i++) {
			System.out.print(c);
		}
	}
	public static void drawBorderRectangle(char c, int height, int base) {
		
		for (int i = 0; i < base; i++) {
			System.out.print(c);
		}
		for (int i = 0; i < height - 2; i++) {
			System.out.println();
			System.out.print(c);
			for (int j = 0; j < base - 2; j++) {
				System.out.print(" ");
			}
			System.out.print(c);
		}
		System.out.println();
		for (int i = 0; i < base; i++) {
			System.out.print(c);
		}
	}
	public static void drawSolidUpsideTriangle (char c, int height) {
		int count = 0;
		int count2 = (height * 2) - 1;
		while(count <= (height - 1)) {
			for (int j = 0; j < count; j++) {
				System.out.print(" ");
			}
			for (int i = 0; i < count2; i++) {
				System.out.print(c);
			}
			System.out.println();
			count++;
			count2-=2;
		}
	}
	public static void drawBorderUpsideTriangle (char c, int height) {
		int count = 1;
		int count2 = (height * 2) - 1;
		for (int i = 0; i < count2; i++) {
			System.out.print(c);
		}
		System.out.println();
		while(count <= (height - 1)) {
			for (int j = 0; j < count; j++) {
				System.out.print(" ");
			}
			System.out.print(c);
			for (int i = 0; i < count2 - 4; i++) {
				System.out.print(" ");
			}
			if (count != (height - 1)) {
				System.out.print(c);
			}
			System.out.println();
			count++;
			count2-=2;
		}
	}
}
