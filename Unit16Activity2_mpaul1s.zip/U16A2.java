import java.util.Arrays;

public class U16A2 {
	public static void main(String[] args) {
		int[] x = {10, 9, 8, 6, 19};
		insertionSort(x);
		System.out.println(Arrays.toString(x));
		
		int[] y = new int[10];
		
		for (int i = 0; i < y.length; i++) {
			y[i] = (int)(Math.random() * 10) + 1;
		}
		insertionSort(y);
		System.out.println(Arrays.toString(y));
		
		int[] z = new int[10];
		
		for (int i = 0; i < z.length; i++) {
			z[i] = i + 1;
		}
		insertionSort(z);
		System.out.println(Arrays.toString(z));
	}
	public static void insertionSort(int[] x) {
		if (x.length <= 1) { //checks for arrays with one element or less
			return;
		}
		else {
			for (int i = 0; i < x.length - 1; i++) {
				if (x[i] > x[i + 1]) { //finds first occurrence where elements are not in order
					int temp = x[i + 1];
					x[i + 1] = x[i];
					x[i] = temp; //swaps elements
					insertionSort(x); //iterates through entire array
				}
			}
		}
	}
}
