package counter;

public class Counter {
	public static int count = 0;
	
	public Counter(int c) {
		count = c;
	}
	public void setCount(int c) {
		count = c;
	}
	public int getCount() {
		return count;
	}
}
