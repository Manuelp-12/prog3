/**
 * This program creates a simple calculator using the Counter and CounterConsoleMenu classes.
 * @author Manuel Paul
 */
package testcounter;
import counter.Counter;
import counterconsolemenu.CounterConsoleMenu;
import java.util.Scanner;

public class TestCounter {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int num = 0;
		
		while(num != 3) {
			CounterConsoleMenu.consoleMenu();
			System.out.println();
			System.out.print("Enter your choice: ");
			num = s.nextInt();
			if (num == 0) {
				CounterConsoleMenu.incrementCount();
			}
			else if (num == 1) {
				CounterConsoleMenu.decrementCount();
			}
			else if (num == 2) {
				CounterConsoleMenu.resetCount();
			}
			else if (num == 3) {
				
			}
			else {
				System.out.println("Please enter a valid number");
			}
		}
		System.out.println("Thank you!");
	}
}
