package counterconsolemenu;
import counter.Counter;

public class CounterConsoleMenu {
	public static void consoleMenu() {
		System.out.print("======================================================================\n"
				+ "Available options: Increment - 0, Decrement - 1, Reset - 2, Quit - 3\n"
				+ "Counter value: " + Counter.count + "\n" + 
				"======================================================================");
	}
	public static void incrementCount() {
		Counter.count++;
	}
	public static void decrementCount() {
		Counter.count--;
	}
	public static void resetCount() {
		Counter.count = 0;
	}
}
