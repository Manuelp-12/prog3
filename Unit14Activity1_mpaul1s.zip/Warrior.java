package warrior;
import player.Player;

public class Warrior extends Player {
	private String weapon = "";
	
	public Warrior() {
		
	}
	public Warrior(String n, int l, int p, int c) {
		super(n, l, p, c);
	}
	public Warrior(String n, int l, int p, int c, String w) {
		super(n, l, p, c);
		weapon = w;
	}
	public String getWeapon() {
		return weapon;
	}
	public void setWeapon(String w) {
		weapon = w;
	}
	public void inBattle() {
		this.setLives(this.getLives() - 1);
	}
}