package merchant;
import player.Player;

public class Merchant extends Player {
	private int money = 0;
	private String goods = "";
	
	public Merchant() {
		
	}
	public Merchant(String n, int l, int p, int c) {
		super(n, l, p, c);
	}
	public Merchant(String n, int l, int p, int c, int m, String g) {
		super(n, l, p, c);
		money = m;
		goods = g;
	}
	public int getMoney() {
		return money;
	}
	public void setMoney(int m) {
		money = m;
	}
	public String getGoods() {
		return goods;
	}
	public void setGoods(String g) {
		goods = g;
	}
	public void checkValues() {
		if (money == 0 || goods == "") {
			this.setLives(this.getLives() - 1);
		}
	}
}
