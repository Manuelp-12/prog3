package player;

public class Player {
	private String name = "";
	private int lives = 5;
	private int points = 0;
	private int credits = 0;
	
	public Player() {
		
	}
	public Player(String n, int l, int p, int c) {
		name = n;
		lives = l;
		points = p;
		credits = c;
	}
	public String getName() {
		return name;
	}
	public void setName(String n) {
		name = n;
	}
	public int getLives() {
		return lives;
	}
	public void setLives(int l) {
		lives = l;
	}
	public int getPoints() {
		return points;
	}
	public void setPoints(int p) {
		points = p;
	}
	public int getCredits() {
		return credits;
	}
	public void setCredits(int c) {
		credits = c;
	}
}
