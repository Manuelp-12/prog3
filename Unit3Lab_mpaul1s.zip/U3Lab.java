/**
 * This class/program prints a song's title, lyrics, and author
 * @author Manuel Paul
 *
 */
public class U3Lab {
	public static void main(String[] args) {
		printTitle();
		System.out.print("by ");
		printAuthor();
		printVerseOne();
	}
	public static void printSong() {
		System.out.println("And, they wishin' and wishin' and wishin' and wishin'\r\n"
				+ "They wishin' on me, yeah\r\n"
				+ "God's plan, God's plan\r\n"
				+ "I hold back, sometimes I won't, yeah\r\n"
				+ "I feel good, sometimes I don't, ayy, don't\r\n"
				+ "I finessed down Weston Road, ayy, 'nessed\r\n"
				+ "Might go down a G-O-D, yeah, wait\r\n"
				+ "I go hard on Southside G, yeah, Way\r\n"
				+ "I make sure that north side eat\r\n"
				+ "And still\r\n"
				+ "Bad things\r\n"
				+ "It's a lot of bad things\r\n"
				+ "That they wishin' and wishin' and wishin' and wishin'\r\n"
				+ "They wishin' on me\r\n"
				+ "Bad things\r\n"
				+ "It's a lot of bad things\r\n"
				+ "That they wishin' and wishin' and wishin' and wishin'\r\n"
				+ "They wishin' on me\r\n"
				+ "Yeah, ayy, ayy (ayy)\r\n"
				+ "God's plan, God's plan\r\n"
				+ "I can't do this on my own, ayy, no, ayy\r\n"
				+ "Someone watchin' this ---- close, yep, close\r\n"
				+ "I've been me since Scarlett Road, ayy, road, ayy\r\n"
				+ "Might go down as G-O-D, yeah, wait\r\n"
				+ "I go hard on Southside G, ayy, Way\r\n"
				+ "I make sure that north side eat, yuh\r\n"
				+ "And still\r\n"
				+ "Bad things\r\n"
				+ "It's a lot of bad things\r\n"
				+ "That they wishin' and wishin' and wishin' and wishin'\r\n"
				+ "They wishin' on me\r\n"
				+ "Yeah, yeah\r\n"
				+ "Bad things\r\n"
				+ "It's a lot of bad things\r\n"
				+ "That they wishin' and wishin' and wishin' and wishin'\r\n"
				+ "They wishin' on me\r\n"
				+ "Yeah");
	}
	public static void printVerseOne() {
		System.out.println("I been movin' calm, don't start no trouble with me\r\n"
				+  "Tryna keep it peaceful is a struggle for me\r\n"
				+ "Don't pull up at 6 AM to cuddle with me\r\n"
				+ "You know how I like it when you lovin' on me\r\n"
				+ "I don't wanna die for them to miss me\r\n"
				+ "Yes, I see the things that they wishin' on me\r\n"
				+ "Hope I got some brothers that outlive me\r\n"
				+ "They gon' tell the story, --- was different with me");
	}
	public static void printVerseTwo() {
		System.out.println("She say, \"Do you love me?\" I tell her, \"Only partly\r\n"
				+ "I only love my bed and my momma, I'm sorry\"\r\n"
				+ "Fifty Dub, I even got it tatted on me\r\n"
				+ "81, they'll bring the crashers to the party\r\n"
				+ "And you know me\r\n"
				+ "Turn the O2 into the O3, dog\r\n"
				+ "Without 40, Oli', there'd be no me\r\n"
				+ "'Magine if I never met the broskis\r\n");
	}
	public static void printTitle() {
		System.out.println("God's Plan");
	}
	public static void printAuthor() {
		System.out.println("Drake");
	}
}
