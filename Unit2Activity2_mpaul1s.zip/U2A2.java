/**
 * This class/program a monetary value into dollars, quarters, dimes, nickels, and pennies
 * @author Manuel Paul
 *
 */
import java.util.Scanner;
public class U2A2 {
	public static void main (String[] args) {
		Scanner s = new Scanner (System.in);
		int dollars = 0;
		int quarters = 0;
		int dimes = 0;
		int nickels = 0;
		int pennies = 0;
		
		System.out.print("Enter a monetary value: ");
		double value = s.nextDouble();
		double newValue = value;
		
		dollars = (int)newValue;
		
		newValue = newValue - dollars;
		quarters = (int)(newValue/0.25);
		
		newValue = newValue - (0.25 * quarters);
		dimes = (int)(newValue/0.1);
		
		newValue = newValue - (0.1 * dimes);
		nickels = (int)(newValue/0.05);
		
		newValue = newValue - (0.05 * nickels);
		pennies = (int)(newValue/0.01);
		
		System.out.println(value + " consists of " + dollars + " dollars, " + quarters + " quarters, " + dimes + " dimes, " + nickels + " nickels, " + pennies + " pennies");
	}
}
