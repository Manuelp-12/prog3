/**
 * This program adds a weak password runtime exception in the setpassword method of the userprofile class
 * author Manuel Paul
 */

package weakpasswordruntimexception;

public class WeakPasswordRuntimeException extends RuntimeException {
	private String message;
	
	public WeakPasswordRuntimeException(String message) { 
		this.message = message; 
	} 
	public String getMessage() { 
		return message; 
	}
}