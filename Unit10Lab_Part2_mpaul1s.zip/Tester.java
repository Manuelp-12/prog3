/**
 * This program adds a weak password runtime exception in the setpassword method of the userprofile class
 * author Manuel Paul
 */

package tester;
import userprofile.UserProfile;
import weakpasswordruntimexception.WeakPasswordRuntimeException;

public class Tester {
	public static void main(String[] args) {
		UserProfile a = new UserProfile("John", "Doe", "johndoe32@gmail.com");
		
		try {
			a.setPassword("abcdefgh1@");
		}
		catch(WeakPasswordRuntimeException e) {
			e.printStackTrace();
		}
		try {
			a.setPassword("abcdefgh");
		}
		catch(WeakPasswordRuntimeException e) {
			e.printStackTrace();
		}
	}
}