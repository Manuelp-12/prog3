package drawable;

public interface Drawable {
	String getName();
	void draw();
}