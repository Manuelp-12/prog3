package car;
import drawable.Drawable;

public class Car implements Drawable {
	String name = "Car";
	
	public String getName() {
		return name;
	}
	public void draw() {
		System.out.println("**********\n"
				         + "***************\n"
				         + "***************\n"
				         + "**         **");
	}
}
