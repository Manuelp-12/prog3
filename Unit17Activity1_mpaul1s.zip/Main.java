package main;
import drawable.Drawable;
import car.Car;
import house.House;
import skyscraper.Skyscraper;
import java.util.ArrayList;

public class Main {
	public static void main(String[] args) {
		ArrayList<Drawable> list = new ArrayList<Drawable>();
		list.add(new Car());
		list.add(new House());
		list.add(new Skyscraper());
		for (Drawable d : list) {
			System.out.println(d.getName());
			d.draw();
			System.out.println();
		}
	}
}