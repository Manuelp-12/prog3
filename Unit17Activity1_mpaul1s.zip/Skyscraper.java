package skyscraper;
import drawable.Drawable;

public class Skyscraper implements Drawable {
	String name = "Skyscraper";
	
	public String getName() {
		return name;
	}
	
	public void draw() {
		System.out.println("***\n" + 
	                       "***\n" + 
	                       "***\n" + 
	                       "***\n" + 
	                       "***\n" + 
	                       "***\n" + 
	                       "***\n" + 
	                       "***\n" + 
	                       "***\n" + 
	                       "***\n");
	}
}
