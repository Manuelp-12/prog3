/**
 * This program creates a game in which the user has to guess a number between 1 and a given value.
 * @author Manuel Paul
 *
 */
import java.util.Scanner;
public class U6A1 {
	public static void main(String[] args) {
		Scanner s = new Scanner (System.in);
		int num;
		int count;
		System.out.println("Welcome to the Secret Number game");
		System.out.print("You will be guessing a number between 1 and N. What do you want that number to be: ");
		while (true) {
			num = s.nextInt();
			if (num > 0) {
				break;
			}
			else {
				System.out.println("Please pick a valid number");
			}
		}
		int randomnum = (int)(num * Math.random()) + 1;
		System.out.print("How many guesses would you like to make: ");
		while (true) {
			count = s.nextInt();
			if (count > 0) {
				break;
			}
			else {
				System.out.println("Please pick a valid number");
			}
		}
		for (int i = count; i > 0; i--) {
			System.out.print("Your guess: ");
			int guess = s.nextInt();
			if (guess > randomnum) {
				System.out.println("Lower");
			}
			else if (guess < randomnum) {
				System.out.println("Higher");
			}
			else {
				System.out.println("Correct!");
				break;
			}
		}
		System.out.print("Enter 1 to play again, or 2 to stop playing: ");
		while (true) {
			int playagain = s.nextInt();
			if (playagain == 2) {
				System.out.println("Thanks for playing!");
				break;
			}
			else if (!(playagain == 1)) {
				System.out.println("Please pick a valid number");
			}
			else {
				program();
			}
		}
	}
	public static void program() {
		Scanner s = new Scanner (System.in);
		int num;
		int count;
		System.out.println("Welcome to the Secret Number game");
		System.out.print("You will be guessing a number between 1 and N. What do you want that number to be: ");
		while (true) {
			num = s.nextInt();
			if (num > 0) {
				break;
			}
			else {
				System.out.println("Please pick a valid number");
			}
		}
		int randomnum = (int)(num * Math.random()) + 1;
		System.out.print("How many guesses would you like to make: ");
		while (true) {
			count = s.nextInt();
			if (count > 0) {
				break;
			}
			else {
				System.out.println("Please pick a valid number");
			}
		}
		for (int i = count; i > 0; i--) {
			System.out.print("Your guess: ");
			int guess = s.nextInt();
			if (guess > randomnum) {
				System.out.println("Lower");
			}
			else if (guess < randomnum) {
				System.out.println("Higher");
			}
			else {
				System.out.println("Correct!");
				break;
			}
		}
		System.out.print("Enter 1 to play again, or 2 to stop playing: ");
		while (true) {
			int playagain = s.nextInt();
			if (playagain == 2) {
				System.out.println("Thanks for playing!");
				break;
			}
			else if (!(playagain == 1)) {
				System.out.println("Please pick a valid number");
			}
			else {
				program();
			}
		}
	}
}
