/**
 * This program sorts and searches multiple arrays and determines their 
 * complexity.
 * @author Manuel Paul
 *
 */
public class Unit15Lab {
	public static void main(String[] args) {
		int[] random = new int[100];
		int[] reverse = new int[100];
		int[] sorted = new int[100];
		
		for (int i = 0; i < random.length; i++) {
			random[i] = (int)((Math.random() * 100) + 1);
		}
		int[] random2 = random;
		
		for (int i = 0; i < reverse.length; i++) {
			reverse[reverse.length - 1 - i] = i + 1;
		}
		int[] reverse2 = reverse;
		
		for (int i = 0; i < sorted.length; i++) {
			sorted[i] = i + 1;
		}
		int[] sorted2 = sorted;
		
		System.out.println("Random array: ");
		
		insertionSort(random);
		selectionSort(random2);
		
		System.out.println("Reverse sorted array: ");
		
		insertionSort(reverse);
		selectionSort(reverse2);
		
		System.out.println("Sorted array: ");
		
		insertionSort(sorted);
		selectionSort(sorted2);
		System.out.println();
		
		System.out.println("Element in array: ");
		long startTime = System.nanoTime();
		linearSearch(sorted, 50);
		long elapsedTime = System.nanoTime () - startTime;    
		System.out.printf ("Linear search completed in: %d nanoseconds\n", elapsedTime);
		
		long startTime2 = System.nanoTime();
		BinarySearch(sorted2, 50);
		long elapsedTime2 = System.nanoTime () - startTime2;    
		System.out.printf ("Binary search completed in: %d nanoseconds\n", elapsedTime2);
		System.out.println();
		
		System.out.println("Element not in array: ");
		long startTime3 = System.nanoTime();
		linearSearch(sorted, -1);
		long elapsedTime3 = System.nanoTime () - startTime3;    
		System.out.printf ("Linear search completed in: %d nanoseconds\n", elapsedTime3);
		
		long startTime4 = System.nanoTime();
		BinarySearch(sorted2, -1);
		long elapsedTime4 = System.nanoTime () - startTime4;    
		System.out.printf ("Binary search completed in: %d nanoseconds\n", elapsedTime4);
	}
	public static void insertionSort(int[] a) {
		long startTime = System.nanoTime();
		
		for (int n = 1; n < a.length; n++) {
			int aTemp = a[n];
			
			int i = n;
			while (i > 0 && aTemp < a[i - 1]) {
				a[i] = a[i - 1];
				i--;
			}
			a[i] = aTemp;
		}
		long elapsedTime = System.nanoTime () - startTime;    
		System.out.printf ("Insertion sort completed in: %d nanoseconds\n", elapsedTime);
	}
	public static void selectionSort(int[] a) {
		long startTime = System.nanoTime();
		
		for (int n = a.length; n > 1; n--) {
			int iMax = 0;
			for (int i = 1; i < n; i++) {
				if (a[i] > a[iMax]) {
					iMax = i;
				}
			}
			int aTemp = a[iMax];
			a[iMax] = a[n - 1];
			a[n - 1] = aTemp;
		}
		long elapsedTime = System.nanoTime () - startTime;    
		System.out.printf ("Selection sort completed in: %d nanoseconds\n", elapsedTime);
	}
	public static int linearSearch(int[] myArr, int key) {
		int foundIt = -1;
		
		for (int i = 0; i<myArr.length; i++) {
			if (myArr[i] == key) {
				foundIt = i;
				break;
			}
		}
		return foundIt;
	}
	public static int BinarySearch(int[] x, int key) {
		// set up the variables we'll need to run this algorithm
		int index = -1,  
			low = 0, 
			high = x.length-1, 
			midpoint = (low + high)/2;
		
		// determine the key's location if it exists
		while (low < high) {
			if (key <= x[midpoint]){
				high = midpoint;
			}
			else {
				low = midpoint + 1;
			}
			midpoint = (low + high)/2;
		}

		// check if the key's really at the index we found, if not leave it set at -1
		if (x[midpoint] == key) {
			index = midpoint;
		}
		
		// return index
		return index;
	}
}
