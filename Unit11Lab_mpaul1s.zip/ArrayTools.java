/**
 * This program uses methods to find data about arrays and change them, for example average, minimum, 
 * maximum, their indexes, and shifting each element left or right.
 * @author Manuel Paul
 * 
 */

package arraytools;

public class ArrayTools {
	public static int minimum(int[] x) {
		int minimum = x[0];
		for (int i = 0; i < x.length; i++) {
			if (x[i] < minimum) {
				minimum = x[i];
			}
		}
		return minimum;
	}
/**
 * returns the minimum element of the given array
 * 
 * Complexity: this method iterates over the entire array, hence it requires
 * time proportional to the size of the array.
 * 
 * Precondition: array contains at least one element
 */
	public static int maximum(int[] x) {
		int maximum = x[0];
		for (int i = 0; i < x.length; i++) {
			if (x[i] > maximum) {
				maximum = x[i];
			}
		}
		return maximum;
	}
/**
 * returns the maximum element of the given array
 * 
 * Complexity: this method iterates over the entire array, hence it requires
 * time proportional to the size of the array.
 * 
 * Precondition: array contains at least one element
 */
	public static int minimumAt(int[] x) {
		int index = 0;
		int minimum = minimum(x);
		for (int i = 0; i < x.length; i++) {
			if (x[i] == minimum) {
				index = i;
			}
		}
		return index;
	}
/**
 * returns the index value of the minimum element of the given array
 * 
 * Complexity: this method iterates over the entire array, checking for the minimum value. It uses 
 * the minimum method, which also iterates over the entire array, so it requires time proportional to
 * two times the size of the array.
 * 
 * Precondition: array contains at least one element
 */
	public static int maximumAt(int[] x) {
		int index = 0;
		int maximum = maximum(x);
		for (int i = 0; i < x.length; i++) {
			if (x[i] == maximum) {
				index = i;
			}
		}
		return index;
	}
/**
 * returns the index value of the maximum element of the given array
 * 
 * Complexity: this method iterates over the entire array, checking for the maximum value. It uses 
 * the maximum method, which also iterates over the entire array, so it requires time proportional to
 * two times the size of the array.
 * 
 * Precondition: array contains at least one element
 * 
 */
	public static double average(int[] x) {
		int total = 0;
		double average = 0.0;
		for (int i = 0; i < x.length; i++) {
			total += x[i];
		}
		average = total / x.length;
		return average;
	}
/**
 * returns the average value of all elements of the given array
 * 
 * Complexity: this method iterates over the entire array, hence it requires
 * time proportional to the size of the array.
 * 
 * Precondition: array contains at least one element
 * 
 */
	public static int find(int[] x, int y) {
		int count = 0;
		int index = 0;
		for (int i = 0; i < x.length; i++) {
			if (y == x[i]) {
				count++;
				index = i;
			}
		}
		if (count == 0) {
			return -1;
		}
		else {
			return index;
		}
	}
/**
 * returns the index value of a given value in the array, or returns -1 if the value is not in the
 * array
 * 
 * Complexity: this method iterates over the entire array, hence it requires
 * time proportional to the size of the array.
 * 
 * Precondition: array contains at least one element
 * 
 */
	public static void shiftLeft(int[] x) {
		int replace = x[0];
		for (int i = 0; i < x.length - 1; i++) {
			x[i] = x[i + 1];
		}
		x[x.length - 1] = replace;
	}
	public static void shiftRight(int[] x) {
		int replace = x[x.length - 1];
		for (int i = x.length - 1; i > 0; i--) {
			x[i] = x[i - 1];
		}
		x[0] = replace;
	}
	public static boolean equals(int[] x, int[] y) {
		if (x.length != y.length) {
			return false;
		}
		for (int i = 0; i < x.length; i++) {
			if (x[i] != y[i]) {
				return false;
			}
		}
		return true;
	}
/**
 * returns true if the two arrays are equal to each other, returns false if they aren't
 * 
 * Complexity: this method can iterate once up to the length of the entire array, hence it requires
 * time proportional from 1 up to the size of the array.
 * 
 * Precondition: each array contains at least one element, the arrays are the same length
 */
 }
