/**
 * This program uses methods to find data about arrays and change them, for example average, minimum, 
 * maximum, their indexes, and shifting each element left or right.
 * @author Manuel Paul
 * 
 */

package main;
import java.util.Arrays;
import java.util.Scanner;
import arraytools.ArrayTools;
public class ArrayToolsTest {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		
		System.out.print("Enter size of the tested array: ");
		int num = s.nextInt();
		
		int[] arr = new int[num];
		for (int i = 0; i < num; i++) {
			arr[i] = (int)(Math.random() * 11);
		}
		System.out.println("Array to be tested: " + Arrays.toString(arr));
		
		System.out.println("minimum: " + ArrayTools.minimum(arr));
		System.out.println("maximum: " + ArrayTools.maximum(arr));
		System.out.println("minimumAt: " + ArrayTools.minimumAt(arr));
		System.out.println("maximumAt: " + ArrayTools.maximumAt(arr));
		System.out.println("average: " + ArrayTools.average(arr));
		
		System.out.print("Enter a number to find in the array: ");
		int finder = s.nextInt();
		
		System.out.println("find " + finder + ": " + ArrayTools.find(arr, finder));
		
		ArrayTools.shiftLeft(arr);
		System.out.println("after shiftLeft: " + Arrays.toString(arr));
		ArrayTools.shiftRight(arr);
		System.out.println("after shiftRight: " + Arrays.toString(arr));
		
		int[] arr2 = new int[num];
		for (int i = 0; i < num; i++) {
			arr2[i] = (int)(Math.random() * 11);
		}
		
		System.out.println("equal to " + Arrays.toString(arr2) + ": " + ArrayTools.equals(arr, arr2));
	}
}
