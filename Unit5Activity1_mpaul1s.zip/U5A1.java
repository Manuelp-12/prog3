/**
 * This program uses methods to perform operations with if/else if statements and switch operators.
 * @author Manuel Paul
 *
 */
import java.util.Scanner;
public class U5A1 {
	public static void main(String[] args) {
		Scanner s = new Scanner (System.in);
		
		System.out.print("Enter two numbers: ");
		double valueOne = s.nextDouble();
		System.out.print("Enter another number: ");
		double valueTwo = s.nextDouble();
		
		System.out.print("Enter an operator (+, -, *, /, %): ");
		char opp = s.next().charAt(0);
		
		System.out.print("Evaluating with if: ");
		System.out.println(evaluateWithIf(valueOne, opp, valueTwo));
		
		System.out.print("Evaluating with switch: ");
		System.out.println(evaluateWithSwitch(valueOne, opp, valueTwo));
	}
	public static double evaluateWithIf(double firstValue, char operator, double secondValue) {
		char c = operator;
		double finalValue = 0;
		
		if (c == '+') {
			finalValue = firstValue + secondValue; //adds 2 values
		}
		else if (c == '-') {
			finalValue = firstValue - secondValue; //subtracts 2 values
		}
		else if (c == '*') {
			finalValue = firstValue * secondValue; //multiplies 2 values
		}
		else if (c == '/') {
			finalValue = firstValue / secondValue; //divides 2 values
		}
		else if (c == '%') {
			finalValue = firstValue % secondValue; //mods 2 values
		}
		else {
			return finalValue; //returns 0 if operator is not supported
		}
		return finalValue; //returns result
	}
	public static double evaluateWithSwitch(double firstValue, char operator, double secondValue) {
		char c = operator;
		double finalValue = 0;
		
		switch (c) {
			case '+':
				finalValue = firstValue + secondValue; //adds 2 values
				break;
			case '-':
				finalValue = firstValue - secondValue; //subtracts 2 values
				break;
			case '*':
				finalValue = firstValue * secondValue; //multiplies 2 values
				break;
			case '/':
				finalValue = firstValue / secondValue; //divides 2 values
				break;
			case '%':
				finalValue = firstValue % secondValue; //mods 2 values
				break;
			default:
				return finalValue; //returns 0 if operator is not supported
		}
		return finalValue; //returns result
	}
}