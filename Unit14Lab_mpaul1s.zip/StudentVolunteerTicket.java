package studentvolunteerticket;
import studentadvanceticket.StudentAdvanceTicket;

public class StudentVolunteerTicket extends StudentAdvanceTicket {
	private int hours = 0;
	
	public StudentVolunteerTicket() {
		
	}
	public StudentVolunteerTicket(int a, String i, int h) {
		super(a, i);
		hours = h;
		
		if (hours > 10) {
			this.setPrice(this.getPrice() * 0.5);
		}
	}
	public StudentVolunteerTicket(String d, String p, String v, int a, String i, int h) {
		super(d, p, v, a, i);
		hours = h;
		
		if (hours > 10) {
			this.setPrice(this.getPrice() * 0.5);
		}
	}
	public int getHours() {
		return hours;
	}
	public void setHours(int h) {
		hours = h;
	}
	public String toooString() {
		return this.tooString() + " volunteered " + this.getHours() + " hours";
	}
}
