package advanceticket;
import ticket.Ticket;

public class AdvanceTicket extends Ticket {
	public AdvanceTicket() {
		
	}
	public AdvanceTicket(int a) {
		this.setAdvanceDays(a);
		
		if (this.getAdvanceDays() >= 10) {
			this.setPrice(this.getPrice() * 0.9);
		}
	}
	public AdvanceTicket(String d, String p, String v, int a) {
		super(d, p, v);
		this.setAdvanceDays(a);
		
		if (this.getAdvanceDays() > 10) {
			this.setPrice(this.getPrice() * 0.9);
		}
	}
}
