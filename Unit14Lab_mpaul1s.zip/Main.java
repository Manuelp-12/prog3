package main;
import ticket.Ticket;
import walkupticket.WalkUpTicket;
import advanceticket.AdvanceTicket;
import studentadvanceticket.StudentAdvanceTicket;
import studentvolunteerticket.StudentVolunteerTicket;

public class Main {
	public static void main(String[] args) {
		WalkUpTicket w = new WalkUpTicket("Dec 12, 7:00 PM", "Youth Orchestra", "Peter and the Wolf");
		
		AdvanceTicket a = new AdvanceTicket("Dec 12, 7:00 PM", "Youth Orchestra", "Peter and the Wolf", 5);
		AdvanceTicket a2 = new AdvanceTicket("Dec 12, 7:00 PM", "Youth Orchestra", "Peter and the Wolf", 9);
		AdvanceTicket a3 = new AdvanceTicket("Dec 12, 7:00 PM", "Youth Orchestra", "Peter and the Wolf", 10);
		AdvanceTicket a4 = new AdvanceTicket("Dec 12, 7:00 PM", "Youth Orchestra", "Peter and the Wolf", 20);
		
		StudentAdvanceTicket s = new StudentAdvanceTicket("Dec 12, 7:00 PM", "Youth Orchestra", "Peter and the Wolf", 5, "mpaul190");
		StudentAdvanceTicket s2 = new StudentAdvanceTicket("Dec 12, 7:00 PM", "Youth Orchestra", "Peter and the Wolf", 9, "mpaul190");
		StudentAdvanceTicket s3 = new StudentAdvanceTicket("Dec 12, 7:00 PM", "Youth Orchestra", "Peter and the Wolf", 10, "mpaul190");
		StudentAdvanceTicket s4 = new StudentAdvanceTicket("Dec 12, 7:00 PM", "Youth Orchestra", "Peter and the Wolf", 20, "mpaul190");
		
		StudentVolunteerTicket v = new StudentVolunteerTicket("Dec 12, 7:00 PM", "Youth Orchestra", "Peter and the Wolf", 10, "mpaul190", 5);
		StudentVolunteerTicket v2 = new StudentVolunteerTicket("Dec 12, 7:00 PM", "Youth Orchestra", "Peter and the Wolf", 20, "mpaul190", 15);
		
		System.out.println("Walkup Tickets");
		System.out.println(w.toString());
		System.out.println();
		
		System.out.println("Advance Tickets");
		System.out.println(a.toString());
		System.out.println();
		System.out.println(a2.toString());
		System.out.println();
		System.out.println(a3.toString());
		System.out.println();
		System.out.println(a4.toString());
		System.out.println();
		
		System.out.println("Student Advance Tickets");
		System.out.println(s.tooString());
		System.out.println();
		System.out.println(s2.tooString());
		System.out.println();
		System.out.println(s3.tooString());
		System.out.println();
		System.out.println(s4.tooString());
		System.out.println();
		
		System.out.println("Student Volunteer Advance Tickets");
		System.out.println(v.toooString());
		System.out.println();
		System.out.println(v2.toooString());
	}
}
