package ticket;

public class Ticket {
	private int id = 0;
	private static int nextID = 0;
	private double price = 0;
	private String date = "";
	private String performer = "";
	private String venue = "";
	private int advanceDays = 0;
			
	public Ticket() {
		id = nextID;
		nextID++;
		price = 50;
	}
	public Ticket(String d, String p, String v) {
		id = nextID;
		nextID++;
		price = 50;
		
		date = d;
		performer = p;
		venue = v;
	}
	public int getID() {
		return id;
	}
	public void setID(int i) {
		id = i;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double p) {
		price = p;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String d) {
		date = d;
	}
	public String getPerformer() {
		return performer;
	}
	public void setPerformer(String p) {
		performer = p;
	}
	public String getVenue() {
		return venue;
	}
	public void setVenue(String v) {
		venue = v;
	}
	public int getAdvanceDays() {
		return advanceDays;
	}
	public void setAdvanceDays(int a) {
		advanceDays = a;
	}
	public String toString() {
		return date + " " + venue + ": " +  performer + "\n" + 
		"(" + advanceDays + " days in advance) Number: " + id + ", Price: " + price;
	}
}
