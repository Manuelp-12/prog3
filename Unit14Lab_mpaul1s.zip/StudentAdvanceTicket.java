package studentadvanceticket;
import advanceticket.AdvanceTicket;

public class StudentAdvanceTicket extends AdvanceTicket {
	private String studentID = "";
	
	public StudentAdvanceTicket() {
		
	}
	public StudentAdvanceTicket(int a, String i) {
		super(a);
		studentID = i;
		this.setPrice(this.getPrice() * 0.5);
	}
	public StudentAdvanceTicket(String d, String p, String v, int a, String i) {
		super(d, p, v, a);
		studentID = i;
		this.setPrice(this.getPrice() * 0.5);
	}
	public String getStudentID() {
		return studentID;
	}
	public void setStudentID(String s) {
		studentID = s;
	}
	public String tooString() {
		return this.toString() + " studentID: " + studentID;
	}
}