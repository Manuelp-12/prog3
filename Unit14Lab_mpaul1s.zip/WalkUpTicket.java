package walkupticket;
import ticket.Ticket;

public class WalkUpTicket extends Ticket {
	public WalkUpTicket() {
		this.setPrice(this.getPrice() + 10);
		this.setAdvanceDays(0);
	}
	public WalkUpTicket(String d, String p, String v) {
		super(d, p, v);
		this.setPrice(this.getPrice() + 10);
		this.setAdvanceDays(0);
	}
}
