/**
 * This program outputs my name, age, and favorite movie
 * @author Manuel Paul
 *
 */
public class Unit1Lab {
	public static void main(String[] args) {
		System.out.println("Hello \nMy name is Manuel.\nI am 18 years old and my favorite movie is Batman.");
	}
}
