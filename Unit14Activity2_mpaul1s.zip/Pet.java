package pet;

public class Pet {
	private String name = "";
	private double weight = 0.0;
	private int age = 0;
	private String sound = "";
	
	public Pet() {
		
	}
	public Pet(String n, double w, int a) {
		name = n;
		weight = w;
		age = a;
	}
	public String getName() {
		return name;
	}
	public void setName(String n) {
		name = n;
	}
	public double getWeight() {
		return weight;
	}
	public void setWeight(double w) {
		weight = w;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int a) {
		age = a;
	}
	public String getSound() {
		return sound;
	}
	public void setSound(String s) {
		sound = s;
	}
}