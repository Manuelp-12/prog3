package cat;
import pet.Pet;

public class Cat extends Pet {
	public Cat() {
		
	}
	public Cat(String n, double w, int a) {
		super(n, w, a);
		this.setSound("meow");
	}
}
