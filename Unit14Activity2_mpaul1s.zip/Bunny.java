package bunny;
import pet.Pet;

public class Bunny extends Pet {
	public Bunny() {
		
	}
	public Bunny(String n, double w, int a) {
		super(n, w, a);
		this.setSound("squeak");
	}
}
