package main;
import pet.Pet;
import dog.Dog;
import cat.Cat;
import bunny.Bunny;
import java.util.ArrayList;

public class Main {
	public static void main(String[] args) {
		double totalage = 0;
		double totalweight = 0;
		double avage = 0;
		double avweight = 0;
		
		Bunny b = new Bunny("Jerry", 3.5, 2);
		Cat c = new Cat("Buster", 8, 5);
		Dog d = new Dog("Rex", 10.5, 6);
		Dog dow = new Dog("Prince", 22, 3);
		
		ArrayList<Pet> pets = new ArrayList<Pet>();
		pets.add(b);
		pets.add(c);
		pets.add(d);
		pets.add(dow);
		
		for (int i = 0; i < pets.size(); i++) {
			System.out.println(pets.get(i).getName() + " " + pets.get(i).getAge() + " years old "
					+ pets.get(i).getWeight() + " lbs");
			System.out.println(pets.get(i).getSound());
			
			totalage += pets.get(i).getAge();
			totalweight += pets.get(i).getWeight();
		}
		avage = totalage / pets.size();
		avweight = totalweight / pets.size();
		
		System.out.println("Average pet age: " + avage + " years");
		System.out.println("Average pet weight: " + avweight + " lbs");
	}
}
