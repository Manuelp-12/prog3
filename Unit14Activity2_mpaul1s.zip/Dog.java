package dog;
import pet.Pet;

public class Dog extends Pet {
	public Dog() {
		
	}
	public Dog(String n, double w, int a) {
		super(n, w, a);
		this.setSound("bowwow");
	}
}
