/**
 * This program creates classes that hold personal information and creates a password.
 * @author Manuel Paul
 *
 */
import java.util.Scanner;

public class UserProfile {
	private String firstName = "";
	private String lastName = "";
	private String email = "";
	private int birth = 0;
	private String phone = null;
	private String password = "";
	
	public static void main(String[] args) {
		String fn = "";
		String ln = "";
		String e = "";
		int b = 0;
		String p = null;
		Scanner s = new Scanner(System.in);
		String prefix = "";
		String suffix = "";
		
		System.out.print("First name: ");
		fn = s.nextLine();
		System.out.print("Last name: ");
		ln = s.nextLine();
		System.out.print("Email: ");
		e = s.nextLine();
		System.out.print("Year of Birth: ");
		b = s.nextInt();
		System.out.print("Phone Number: ");
		p = s.nextLine();
		p = s.nextLine();
		
		UserProfile a = new UserProfile(fn, ln, e, b, p);
		System.out.println(a.getAttributes());
		System.out.println("Current password: " + a.password + " before regeneration");
		System.out.print("Prefix: ");
		prefix = s.nextLine();
		System.out.print("Suffix: ");
		suffix = s.nextLine();
		System.out.println("New password: " + a.regeneratePassword(prefix, suffix));
		
		System.out.print("First name: ");
		fn = s.nextLine();
		System.out.print("Last name: ");
		ln = s.nextLine();
		System.out.print("Email: ");
		e = s.nextLine();
		
		UserProfile c = new UserProfile(fn, ln, e);
		System.out.println(c.getAttributes());
	}
	public UserProfile(String fn, String ln, String e, int b, String p) {
		firstName = fn;
		lastName = ln;
		email = e;
		birth = b;
		phone = p;
		
		int num1 = (int)((Math.random() * 9999) + 10);
		int num2 = (int)((Math.random() * 99999) + 100);
		password = "!" + fn + num1 + ln + num2;
	}
	public UserProfile(String fn, String ln, String e) {
		firstName = fn;
		lastName = ln;
		email = e;
		
		int num1 = (int)((Math.random() * 9999) + 10);
		int num2 = (int)((Math.random() * 99999) + 100);
		password = "!" + fn + num1 + ln + num2;
	}
	public void setFirstName(String x) {
		firstName = x;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setLastName(String x) {
		lastName = x;
	}
	public String getLastName() {
		return lastName;
	}
	public void setEmail(String x) {
		email = x;
	}
	public String getEmail() {
		return email;
	}
	public void setBirth(int x) {
		birth = x;
	}
	public int getBirth() {
		return birth;
	}
	public void setPhone(String x) {
		phone = x;
	}
	public String getPhone() {
		return phone;
	}
	public void setPassword(String x) {
		password = x;
	}
	public String getPassword() {
		return password;
	}
	public String regeneratePassword(String pre, String suf) {
		int num1 = (int)((Math.random() * 9999) + 10);
		int num2 = (int)((Math.random() * 99999) + 100);
		password = "!" + pre + num1 + suf + num2;
		return password;
	}
	public String getAttributes() {
		return "Name: " + firstName + " " + lastName+ "\nEmail: " + email + "\nYear of Birth: " + 
				birth + "\nPassword: *****\nPhone: " + phone;
	}
}
